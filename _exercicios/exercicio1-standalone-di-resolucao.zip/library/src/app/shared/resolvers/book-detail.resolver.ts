import { inject } from '@angular/core';
import { ResolveFn } from '@angular/router';
import { Book } from '../../types/book';
import { BooksService } from '../../services/books.service';

export const bookDetailResolver: ResolveFn<Book> = (route) => {
  const book = inject(BooksService);
  const id = +(route.paramMap.get('id') ?? 0);

  return book.getBookById(id);
};
