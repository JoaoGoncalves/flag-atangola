import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [],
  template: `
    <section class='contact'>
      CONTACT COMPONENT
    </section>
  `,
  styles: ``
})
export class ContactComponent {

}
