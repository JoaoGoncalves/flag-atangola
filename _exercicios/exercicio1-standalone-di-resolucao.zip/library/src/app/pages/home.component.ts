import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  template: `
    <section class='home'>
      HOME COMPONENT
    </section>
  `,
  styles: ``
})
export class HomeComponent {

}
