import { Component, inject } from '@angular/core';
import { BooksService } from '../../services/books.service';

@Component({
  selector: 'app-book-filters',
  standalone: true,
  imports: [],
  
template: `
    <section class="filters">
      <button (click)="showAllBooks()">show all books</button>
      <button (click)="showReadBooks()">show Read books</button>
      <button (click)="showNotReadBooks()">show Not Read books</button>
    </section>
  `,
  styles: ``
})
export class BookFiltersComponent {
  private readonly booksService = inject(BooksService)

  showReadBooks(){
    this.booksService.showReadBooks();
  }
  showNotReadBooks(){
    this.booksService.showNotReadBooks();
  }
  showAllBooks(){
    this.booksService.showAllBooks();
  }

}
