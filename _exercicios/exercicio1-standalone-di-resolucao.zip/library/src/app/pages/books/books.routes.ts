import { bookDetailResolver } from "../../shared/resolvers/book-detail.resolver";
import { BookDetailComponent } from "./book-detail.component";
import { BookFiltersComponent } from "./book-filters.component";
import { BookListComponent } from "./book-list.component";

export const routes = [
  { path: "list", component: BookListComponent },
  {
    path: "filters",
    component: BookFiltersComponent,
  },
  {
    path: "details/:id",
    resolve: {book: bookDetailResolver},
    component: BookDetailComponent,
  },
];
