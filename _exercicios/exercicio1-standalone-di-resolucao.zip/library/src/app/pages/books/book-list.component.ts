import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AsyncPipe, NgFor } from '@angular/common';
import { BooksService } from '../../services/books.service';
import { BookFiltersComponent } from './book-filters.component';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [RouterLink, NgFor, AsyncPipe, BookFiltersComponent],
  template: `
    <h1>Livros de JS</h1>
    <app-book-filters></app-book-filters>
   <section class="grid">
     <article *ngFor="let book of books$ | async">
        <h1>
          <a  [routerLink]="['/books/details', book.id]">{{book.title}}</a>
        </h1>
        <h2>{{book.author}}</h2>
        <img src="/livros/{{book.imageUrl}}" >
        <p>Already Read: {{ book.alreadyRead ? '✅' : '❌' }}</p>
        <button (click)="deleteBook(book.id)">Delete Book</button>
     </article>
   </section>
  `,
  styles: ``
})
export class BookListComponent {
  private readonly booksService = inject(BooksService);
  books$ = this.booksService.books$;

  deleteBook(id: number){
    this.booksService.deleteBook(id);
   }

}
