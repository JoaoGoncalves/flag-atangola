import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Book } from '../types/book';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class BooksService {
  private readonly http = inject(HttpClient);
  private _books = new BehaviorSubject<Book[]>([]);
  readonly books$ = this._books.asObservable();

  private books: Book[] = [];
  private filteredBooks: Book[] = [];
  
  constructor(){
    this.getBooks();
  }

  getBooks() {
   this.http.get<Book[]>('https://my-json-server.typicode.com/JoaoGoncalves/biblio-api/books').subscribe(val => {
      this._books.next(val);
      this.books = val;
    })
  }

  getBookById(id: number){
    return this.http.get<Book>(`https://my-json-server.typicode.com/JoaoGoncalves/biblio-api/books/${id}`)
  }

  deleteBook(bookId: number){
    this.http.delete(`https://my-json-server.typicode.com/JoaoGoncalves/biblio-api/books/${bookId}`).subscribe( val => {
      this.books = this.books.filter( b => b.id !== bookId);
      this._books.next(this.books);
    })
  }

  showReadBooks (){
    this.filteredBooks = this.books.filter( b => b.alreadyRead === true);
    this._books.next(this.filteredBooks);
  }

  showNotReadBooks (){
    this.filteredBooks = this.books.filter( b => b.alreadyRead === false);
    this._books.next(this.filteredBooks);
  }

  showAllBooks(){
    this.filteredBooks = this.books;
    this._books.next(this.filteredBooks);
  }
}
