import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { isAuth } from './shared/functions/is-auth';
import { AsyncPipe, NgIf } from '@angular/common';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, NgIf, AsyncPipe],
  template: `
    <h1>Welcome to {{title}}!</h1>
    <hr>
    <nav>
      <a [routerLink]="['/']">Home</a>
      <a [routerLink]="['/books/list']">Books</a>
      <a [routerLink]="['/contact']">Me</a>
      <button (click)="logout()" *ngIf="isAuth$ | async">Logout</button>
      <button (click)="login()" *ngIf="!(isAuth$ | async)">Login</button>
      
    </nav>

    <router-outlet />
  `,
  styles: [],
})
export class AppComponent {
  router = inject(Router)
  authService = inject(AuthService)


  title = 'My Wonderfull Books';
  isAuth$ = isAuth();

  login(){
    this.router.navigate(['/login']);
  }

  logout(){
    this.authService.logout();
    this.router.navigate(['/login']);
  }


}
