import { Routes } from "@angular/router";
import { HomeComponent } from "./pages/home.component";
import { NotFoundComponent } from "./pages/not-found.component";
import { LoginComponent } from "./pages/login.component";
import { BooksService } from "./services/books.service";
import { authGuard } from "./shared/guards/auth.guard";

export const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "login", component: LoginComponent },
  {
    path: "contact",
    loadComponent: () =>
      import("./pages/contact.component").then((m) => m.ContactComponent),
  },
  {
    path: "books",
    providers: [BooksService],
    canActivate: [authGuard],
    loadChildren: () =>
      import("./pages/books/books.routes").then((m) => m.routes),
  },
  { path: "**", component: NotFoundComponent },
];
