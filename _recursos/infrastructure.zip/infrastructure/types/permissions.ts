export type Permissions =
  | 'ViewEmployees'
  | 'EditEmployeeGeneralDetails'
  | 'EditEmployeePrivateDetails'
  | 'DeleteEmployee'
  | 'CreateEmployee';
